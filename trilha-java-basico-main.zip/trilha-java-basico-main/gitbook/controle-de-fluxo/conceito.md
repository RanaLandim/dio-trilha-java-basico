# Conceito

Controle de fluxo é a habilidade de ajustar a maneira como um programa realiza suas tarefas. Por meio de instruções especiais, chamadas de comandos, essas tarefas podem ser executadas seletivamente, repetidamente ou excepcionalmente.

### Classificação:&#x20;

* **Estruturas condicionais:** if-else, switch-case&#x20;
* **Estruturas de repetição:** for, while, do-while
*   **Estruturas de exceções:** try-catch-finally, throw

    &#x20;

