# Abstração

