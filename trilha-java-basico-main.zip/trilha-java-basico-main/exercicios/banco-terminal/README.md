# DIO - Trilha Java Básico
www.dio.me

#### Autores
- [Gleyson Sampaio](https://github.com/glysns)

## Exercício operadores
Crie o programa chamado `BancoTerminal.java` para implementar o algorítmo conforme abaixo:

O programa deverá simular uma operação de saque onde:

1. Terá uma variável denominada `saldo` do tipo double contendo o valor inicial igual a 25;
1. Terá uma variável denominada de `valor solicitado` do tipo double contendo o valor inicial igual a 18;
1. Criar uma expressão relacional para que caso o saldo seja `maior` que o valor solicitado, o saldo recebe o novo valor como saldo é igual saldo menos o valor solicitado. Caso o saldo seja menor que o valor solicitado, devemos exibir a mensagem "Saldo insuficiente";
1. Imprima o valor do saldo;

1. Em seguida, realize a mesma execução do programana agora com os valores saldo igual a 15 e valor solicitado igual a 22 e exiba o resultado;
