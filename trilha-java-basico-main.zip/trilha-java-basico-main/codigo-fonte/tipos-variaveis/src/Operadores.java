public class Operadores {
    public static void main(String[] args) {
        
    }
}
